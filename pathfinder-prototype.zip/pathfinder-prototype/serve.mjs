// Pathfinder server. No dependencies; needs Node 18+.
//   cp .env.example .env   (add Azure keys, optional)
//   node serve.mjs          -> http://localhost:4173
import { loadEnv } from './lib/env.mjs';
import { createSync } from './lib/sync.mjs';
import { createAI } from './lib/ai.mjs';
import { enrichListings } from './lib/ai-tasks.mjs';
import { createApp } from './lib/server.mjs';
import { createStore } from './lib/store.mjs';

loadEnv();
const env = process.env;
const log = m => console.log(`[${new Date().toISOString()}] ${m}`);
const ai = createAI(env);
const enrich = ai.features.chat && env.AI_ENRICH_LISTINGS !== 'false' ? ls => enrichListings(ai, ls) : null;
const sync = createSync({ dataDir: 'data', base: (env.YOMA_API_BASE || 'https://api.yoma.world/api/v3').replace(/\/+$/, ''), enrich, log });
const hour = Math.min(23, Math.max(0, Number(env.SYNC_HOUR ?? 5) || 0));
sync.schedule(hour);

const port = Number(env.PORT) || 4173;
const rateLimit = { max: Number(env.AI_RATE_LIMIT) || 60, windowMs: 10 * 60e3 };
const store = createStore('data');
const yomaAuth = env.YOMA_AUTH_ISSUER && env.YOMA_AUTH_CLIENT_ID && env.PUBLIC_URL
  ? { issuer: env.YOMA_AUTH_ISSUER, clientId: env.YOMA_AUTH_CLIENT_ID, clientSecret: env.YOMA_AUTH_CLIENT_SECRET || '', publicUrl: env.PUBLIC_URL } : null;
createApp({ sync, ai, store, staffCode: env.STAFF_CODE || '', accessCode: env.PILOT_ACCESS_CODE || '', trustProxy: env.TRUST_PROXY === 'true', demoVoice: env.DEMO_BROWSER_VOICE === 'true', yomaAuth, yomaBase: (env.YOMA_API_BASE || 'https://api.yoma.world/api/v3').replace(/\/+$/, ''), rateLimit, log }).listen(port, () => {
  log(`Pathfinder running at http://localhost:${port}`);
  log(`AI: ${ai.provider === 'none' ? 'off (keyword rules and templates)' : `${ai.provider}, voice ${ai.features.voice ? 'on' : 'off'}`}`);
  log(`Yoma: ${sync.get().source} copy loaded; daily sync at ${String(hour).padStart(2, '0')}:00`);
  if (env.PILOT_ACCESS_CODE) log('Access code required (PILOT_ACCESS_CODE is set)');
  if (env.DEMO_BROWSER_VOICE === 'true') log('DEMO ONLY: browser speech recognition is on (audio goes to Google). Turn off for the pilot.');
  log(env.STAFF_CODE ? `Staff case inbox: http://localhost:${port}/staff?code=…` : 'Staff case inbox off (set STAFF_CODE to turn it on)');
});
